$(document).ready(function() {
    // all custom jQuery will go here
	//$("#edit-role-change").
	console.log("dfgdf");
	jQuery("#edit-role-change div:nth-child(3) input").attr('checked','checked');
	//jQuery("#edit-role-change-data-entry").attr('readonly','readonly');
});