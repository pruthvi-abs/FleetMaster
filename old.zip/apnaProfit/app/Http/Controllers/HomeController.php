<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//use App\Slider;
//use App\Maincategory;
//use App\Category;
use App\Themesetting;
use Carbon\Carbon;
use Illuminate\Support\Facades\Session;
use Mail;
use Config;
use DB;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
     public function __construct()
     {
         //$this->middleware('auth');
     }
     public function pagenotfound(){
      $data['pagetitle']="404";
      return view('errors.404');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
     public function index()
     {

       $data['pagetitle']="Home Page";
       //$frontslider=Slider::select('title','description','image','btntitle','btnlink')->get();
       //$data['frontslider']=$frontslider;
       return view('front.home.index')->with($data);
     }
}
