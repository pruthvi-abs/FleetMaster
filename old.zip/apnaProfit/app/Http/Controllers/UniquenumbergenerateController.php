<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Role;
use App\Uniquenumbergenerate;
//use App\Systemconfig;
use Auth;
use DataTables;
use Validator;
use Carbon\Carbon;
use Mail;
use Illuminate\Support\Facades\DB;
use Config;

class UniquenumbergenerateController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $data['webpage']='Uniquenumbergenerate';
        $data['action']='Unique Number Generate';
        return view('admin.uniquenumbergenerates.index')->with($data);
    }
    function getUniquenumbergenerate()
    {
        // $customthemesetting = customthemesetting();
        $user = Auth::user();
        $uniquenumbergenerates=Uniquenumbergenerate::select('id','uniquenumber','user_id','created_at')->orderBy('created_at','desc')->get();
        $uniquenumbergenerate_data=array();
        $i=1;
        foreach($uniquenumbergenerates as $uniquenumbergenerate){
          $uniquenumbergenerate_data[$i]['sr_no']=$i;
          $uniquenumbergenerate_data[$i]['id']=$uniquenumbergenerate->id;
          $uniquenumbergenerate_data[$i]['uniquenumber']=$uniquenumbergenerate->uniquenumber;
          if($uniquenumbergenerate->user_id==""){
            $uniquenumbergenerate_data[$i]['user_name']="";
          }else{
            $uniquenumbergenerate_data[$i]['user_name']=Username($uniquenumbergenerate->user_id);
          }

          //$uniquenumbergenerate_data[$i]['created_at']=Carbon::parse($role->created_at)->format($customthemesetting->datetime_format);
          $uniquenumbergenerate_data[$i]['created_at']=Carbon::parse($uniquenumbergenerate->created_at)->format('Y-m-d H:i:s');
          $i++;
        }
        return Datatables::of($uniquenumbergenerate_data)->make(true);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
      $data['webpage']='Uniquenumbergenerate';
      $data['action']='Unique Number Generate -> Create Unique Number Generate';
      return view('admin.uniquenumbergenerates.create')->with($data);
    }

    public function uniquenumbergeneratesbulk(){
      $data['webpage']='Uniquenumbergenerate';
      $data['action']='Bulk Unique Number Generate -> Create Bulk';
      $data['bulknumberskip']='new';
      return view('admin.uniquenumbergenerates.bulk')->with($data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $this->validate($request, [
            'uniquenumber' => 'required|max:191',
        ]);
        $Uniquenumbergenerate = new Uniquenumbergenerate;
        $Uniquenumbergenerate->uniquenumber = $request->uniquenumber;
        $Uniquenumbergenerate->save();
        return redirect('uniquenumbergenerates')->with('success','Information added successfully');
    }

    public function uniquenumbergeneratesbulksave(Request $request)
    {
        //
        $this->validate($request, [
            'bulkuniquenumber' => 'required|file|mimes:csv'
        ]);
        $path = $request->file('bulkuniquenumber')->getRealPath();
        $data = array_map('str_getcsv', file($path));
        $csv_data = array_slice($data, 0, 2);
        //print_r($csv_data);die;
        $uniquenumber_skip="";
        for($i=0;$i<count($csv_data);$i++){
           $unique_number = $csv_data[$i][0];
           //echo $unique_number."\n";
           $finduniquenumber = Uniquenumbergenerate::where('uniquenumber',$unique_number)->first();
           if($finduniquenumber==null){
             $Uniquenumbergenerate = new Uniquenumbergenerate;
             $Uniquenumbergenerate->uniquenumber = $unique_number;
             $Uniquenumbergenerate->save();
           }else{
             $uniquenumber_skip.=$unique_number.",";
           }
        }
        $data['webpage']='Uniquenumbergenerate';
        $data['action']='Bulk Unique Number Generate -> Create Bulk';
        $data['bulknumberskip']=$uniquenumber_skip;
        //echo "cal...";die;
        return view('admin.uniquenumbergenerates.bulk')->with($data);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      $data['uniquenumbergenerate']=Uniquenumbergenerate::findOrFail($id);
      $data['webpage']='Uniquenumbergenerate';
      $data['action']='Unique Number Generate -> Edit Unique Number Generate';
      return view('admin.uniquenumbergenerates.edit')->with($data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $this->validate($request, [
            'uniquenumber' => 'required|max:191',
        ]);
        $Uniquenumbergenerate=Uniquenumbergenerate::findOrFail($id);
        $Uniquenumbergenerate->uniquenumber = $request->uniquenumber;
        $Uniquenumbergenerate->save();
        return redirect('uniquenumbergenerates')->with('success','Information changed successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
