<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(){
        // echo "call";
        // die;
        $data['webpage']='Dashboard';
        $data['action']='Dashboard';
        return view('admin.dashboard.admindashboard')->with($data);
    }
}
