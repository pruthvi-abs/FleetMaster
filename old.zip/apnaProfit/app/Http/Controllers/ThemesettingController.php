<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Themesetting;
use Auth;
use DataTables;
use Validator;
use Carbon\Carbon;
use Mail;
use Illuminate\Support\Facades\DB;
use Config;

class ThemesettingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
     public function index(){

     }
     public function ShowConfig(){
       $data['webpage']='Theme Setting';
       $data['action']='Theme Setting -> Edit Theme Setting';
       $system_config=Themesetting::where('id',1)->get();
       $data['systemconfig']=$system_config[0];
       return view('admin.themesetting.showconfig')->with($data);
     }

     public function EditConfig(Request $request, $id){
      //  echo $id; die;
      // var_dump($request->app_title);
      // var_dump($request->app_description);
      // var_dump($request->smtp_website_name);
      // var_dump($request->smtp_server);
      // var_dump($request->smtp_port);
      // var_dump($request->smtp_email);
      // var_dump($request->smtp_email_pass);
      // var_dump($request->smtp_from_name);
      // var_dump($request->smtp_from_email);
      // var_dump($request->smtp_transport_exp);
      // var_dump($request->smtp_encryption);
      // var_dump($request->currency);
      // var_dump($request->app_image);
      // var_dump($request->app_favicon);
      // var_dump($request->front_email);
      // var_dump($request->front_mobile);
      // die;
       $this->validate($request, [
           'app_title' => 'required',
           'app_description' => 'required',
           'smtp_website_name' => 'required',
           'smtp_server' => 'required',
           'smtp_port' => 'required',
           'smtp_email' => 'required',
           'smtp_email_pass' => 'required',
           'smtp_from_name' => 'required',
           'smtp_from_email' => 'required',
           'smtp_transport_exp' => 'required',
           'smtp_encryption' => 'required',
           'currency' => 'required',
      ]);

       $systemconfig=Themesetting::findOrFail($id);

       $systemconfig->app_title = $request->app_title;
       $systemconfig->app_description = $request->app_description;
       //$systemconfig->app_image = $request->app_image;
       if($file=$request->file('app_image')){
         $userimage = time().$file->getClientOriginalName();
         $location='public/logo/';
         $file->move($location,$userimage);
         $systemconfig->app_image = $userimage;
       }
       if($file=$request->file('app_favicon')){
         $faviconuserimage = time().$file->getClientOriginalName();
         $location='public/logo/';
         $file->move($location,$faviconuserimage);
         $systemconfig->app_favicon = $faviconuserimage;
       }

      //  $systemconfig->datetime_format = $request->datetime_format;
      //  $systemconfig->phone_format = $request->phone_format;
       $systemconfig->front_email = $request->front_email;
       $systemconfig->front_mobile = $request->front_mobile;
       $systemconfig->smtp_website_name = $request->smtp_website_name;
       $systemconfig->smtp_server = $request->smtp_server;
       $systemconfig->smtp_port = $request->smtp_port;
       $systemconfig->smtp_email = $request->smtp_email;
       $systemconfig->smtp_email_pass = $request->smtp_email_pass;
       $systemconfig->smtp_from_name = $request->smtp_from_name;
       $systemconfig->smtp_from_email = $request->smtp_from_email;
       $systemconfig->smtp_transport_exp = $request->smtp_transport_exp;
       $systemconfig->smtp_encryption = $request->smtp_encryption;
       $systemconfig->currency = $request->currency;

       $systemconfig->save();

       return redirect('showconfig')->with('success','Information changed successfully');
     }

     public function Testmail(Request $request){
       $customthemesetting = customthemesetting();
       $mail = DB::table('themesettings')->where('id',1)->first();
       if ($mail){
         $config = array(
             'driver'     => $mail->smtp_transport_exp,
             'host'       => $mail->smtp_server,
             'port'       => $mail->smtp_port,
             'from'       => array('address' => $mail->smtp_from_email, 'name' => $mail->smtp_from_name),
             'encryption' => $mail->smtp_encryption,
             'username'   => $mail->smtp_email,
             'password'   => $mail->smtp_email_pass,
             'sendmail'   => '/usr/sbin/sendmail -bs',
             'pretend'    => false,
         );
         Config::set('mail', $config);
       }

       $to_name = $mail->smtp_from_name;
       $to_email = $mail->smtp_from_email;
       $mail_data['name'] = 'Pruthvi';
       $mail_data['customthemesetting'] = $customthemesetting;
       Mail::send('admin.mail.test', $mail_data, function($message) use ($to_name, $to_email) {
         $message->to($to_email, $to_name)->subject('Test Mail');
       });
       return redirect('showconfig')->with('success','Mail Send Successfully');
     }
}
