<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\User;
use App\Photo;
use App\Role;
use App\Country;
use App\Systemconfig;
use Auth;
use DataTables;
use Validator;
use Carbon\Carbon;
use Mail;
use Illuminate\Support\Facades\DB;
use Config;

use Illuminate\Http\Request;

class AdminUsersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $data['webpage']='UsersManagement';
        $data['action']='Users Management';
        $data['menu']='master';

        return view('admin.user.index')->with($data);
    }
    function getUsers()
    {
      $customthemesetting = customthemesetting();
      //$user_comp_id = Auth::user()->comp_id;
      $users=User::select('id','role_id','commission','name','firstname','lastname','email','is_active','created_at')->whereIn('role_id',[1,2,3,4])->get();
      $users_data=array();
      $i=1;
      foreach($users as $user){
        $users_data[$i]['sr_no']=$i;
        $users_data[$i]['role_id']=$user->role->name;
        if($user->commission==""){
          $users_data[$i]['commission']="";
        }else{
          $users_data[$i]['commission']=$user->commission."%";
        }
        $users_data[$i]['name']=$user->name;
        $users_data[$i]['firstname']=$user->firstname . ' ' . $user->lastname;
        $users_data[$i]['email']=$user->email;
        $flag="";
        if($user->is_active==1){ $flag="Active"; }else{ $flag="In Active"; }
        $users_data[$i]['is_active']=$flag;
        $users_data[$i]['created_at']=Carbon::parse($user->created_at)->format('Y-m-d H:i:s');
        $users_data[$i]['id']=$user->id;
        $i++;
      }
      return Datatables::of($users_data)->make(true);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $data['webpage']='UsersManagement';
        $data['action']='Users Management -> Create User';
        $data['menu']='master';
        $role=Role::where('id','!=',4)->where('id','!=',1)->pluck('name','id')->all();
        $data['role']=$role;
        $country=Country::pluck('country_name','country_name')->all();
        $data['country']=$country;
        return view('admin.user.create')->with($data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      $customthemesetting = customthemesetting();
        //
        //return $request;
        if($request->role_id != '1' ){
          $this->validate($request, [
            'role_id' => 'required',
            'fname' => 'required|max:191',
            'mname' => 'required|max:191',
            'lname' => 'required|max:191',
            'email' => 'required|unique:users',
            'mobile' => 'required',
            'password' => 'required',
            'cpassword' => 'required',
            'country' => 'required',
            'state' => 'required',
            'city' => 'required',
            'pincode' => 'required',
            'address' => 'required',
            'business_logo' => 'required',
            'bname' => 'required',
            'bemail' => 'required',
            'bmobile' => 'required',
            'desc' => 'required',
            'commission' => 'required',
          ]);
        } else {
          $this->validate($request, [
            'role_id' => 'required',
            'fname' => 'required|max:191',
            'mname' => 'required|max:191',
            'lname' => 'required|max:191',
            'email' => 'required',
            'mobile' => 'required',
            'password' => 'required',
            'cpassword' => 'required',
            'country' => 'required',
            'state' => 'required',
            'city' => 'required',
            'pincode' => 'required',
            'address' => 'required',
          ]);
        }

        // echo 'test';
        // die;

        $user = new User;
        $user->role_id=$request->role_id;
        $user->firstname=$request->fname;
        $user->middlename=$request->mname;
        $user->lastname=$request->lname;
        $user->name=$request->fname . ' ' . $request->mname . ' ' . $request->lname;
        $user->email=$request->email;
        $user->mobile=$request->mobile;
        if($file=$request->file('photo_id')){
          $userimage = time().$file->getClientOriginalName();
          $location='public/userimages/';
          $file->move($location,$userimage);
          $photo = Photo::create(['file'=>$userimage]);
          $photo_id = $photo->id;
          $user->profile_image = $photo_id;
        }
        $user->is_active=1;
        if($request->password == $request->cpassword){
          $user->password=bcrypt($request->password);
        } else {
          return redirect('users')->with('danger','Passwrod and Confirm Password should be same');
        }
        $user->country=$request->country;
        $user->state=$request->state;
        $user->city=$request->city;
        $user->pincode=$request->pincode;
        $user->address=$request->address;

        if(($request->role_id != '1') || ($request->role_id != '4')){
          if($file=$request->file('business_logo')){
            $userimage = time().$file->getClientOriginalName();
            $location='public/businessimages/';
            $file->move($location,$userimage);
            $photo = Photo::create(['file'=>$userimage]);
            $business_logo = $photo->id;
            $user->business_logo = $business_logo;
          }
          $user->business_name=$request->bname;
          $user->business_email=$request->bemail;
          $user->business_number=$request->bmobile;
          $user->business_desc=$request->desc;
          $user->commission=$request->commission;
        }
        $user->save();

        $mail = DB::table('themesettings')->where('id',1)->first();
        if ($mail){
          $config = array(
              'driver'     => $mail->smtp_transport_exp,
              'host'       => $mail->smtp_server,
              'port'       => $mail->smtp_port,
              'from'       => array('address' => $mail->smtp_from_email, 'name' => $mail->smtp_from_name),
              'encryption' => $mail->smtp_encryption,
              'username'   => $mail->smtp_email,
              'password'   => $mail->smtp_email_pass,
              'sendmail'   => '/usr/sbin/sendmail -bs',
              'pretend'    => false,
          );
          Config::set('mail', $config);
        }

        // User Mail
        $to_name = $request->fname. ' ' . $request->lname;
        $to_email = $request->email;
        $mail_data['name'] = $request->fname. ' ' . $request->lname;
        $mail_data['password'] = $request->password;
        $mail_data['email'] = $request->email;
        $mail_data['customthemesetting'] = $customthemesetting;
        Mail::send('admin.mail.userregister', $mail_data, function($message) use ($to_name, $to_email) {
          $message->to($to_email, $to_name)->subject('ApnaProfit - User Registered');
        });

        //Admin Mail
        $to_name = "Admin";
        $to_email = $customthemesetting->front_email;
        $mail_data['name'] = $request->fname. ' ' . $request->lname;
        //$mail_data['password'] = $request->password;
        $mail_data['email'] = $request->email;
        $mail_data['customthemesetting'] = $customthemesetting;
        Mail::send('admin.mail.adminuserregister', $mail_data, function($message) use ($to_name, $to_email) {
          $message->to($to_email, $to_name)->subject('ApnaProfit - User Registered');
        });

        return redirect('users')->with('success','Information added successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $user = User::findOrFail($id);
        $data['user']=$user;
        $role=Role::where('id','!=',4)->where('id','!=',1)->pluck('name','id')->all();
        $data['role']=$role;
        $country=Country::pluck('country_name','country_name')->all();
        $data['country']=$country;
        $data['webpage']='UsersManagement';
        $data['action']='Users Management -> Edit User';
        $data['menu']='';
        return view('admin.user.edit')->with($data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //return $request;
        /*
        echo "Role ID ".$request->role_id."\n";
        echo "fname ID ".$request->firstname."\n";
        echo "mname ID ".$request->middlename."\n";
        echo "lname ID ".$request->lastname."\n";
        echo "mobile ID ".$request->mobile."\n";
        echo "country ID ".$request->country."\n";
        echo "state ID ".$request->state."\n";
        echo "city ID ".$request->city."\n";
        echo "pincode ID ".$request->pincode."\n";
        echo "address ID ".$request->address."\n";
        echo "bname ID ".$request->business_name."\n";
        echo "bnumber ID ".$request->business_number."\n";
        echo "bdesc ID ".$request->business_desc."\n";
        echo "commission ID ".$request->commission."\n";
        echo "call...";die;
        */
        if($request->role_id != '1' ){
          $this->validate($request, [
            'role_id' => 'required',
            'firstname' => 'required|max:191',
            'middlename' => 'required|max:191',
            'lastname' => 'required|max:191',
            'mobile' => 'required',
            'country' => 'required',
            'state' => 'required',
            'city' => 'required',
            'pincode' => 'required',
            'address' => 'required',
            'business_name' => 'required',
            'business_number' => 'required',
            'business_desc' => 'required',
            'commission' => 'required',
          ]);
        } else {
          $this->validate($request, [
            'role_id' => 'required',
            'fname' => 'required|max:191',
            'mname' => 'required|max:191',
            'lname' => 'required|max:191',
            'mobile' => 'required',
            'country' => 'required',
            'state' => 'required',
            'city' => 'required',
            'pincode' => 'required',
            'address' => 'required',
          ]);
        }

        $user = User::findOrFail($id);
        $input = $request->all();
        if($file=$request->file('photo_id')){
          $userimage = time().$file->getClientOriginalName();
          $location='public/userimages/';
          $file->move($location,$userimage);
          $photo = Photo::create(['file'=>$userimage]);
          $photo_id = $photo->id;
          $input['photo_id'] = $photo_id;
        }
        $user->update($input);

        $user = User::findOrFail($id);
        $input = $request->all();
        $input['role_id']=$request->role_id;
        $input['firstname']=$request->firstname;
        $input['middlename']=$request->middlename;
        $input['lastname']=$request->lastname;
        $input['name']=$request->firstname . ' ' . $request->middlename . ' ' . $request->lastname;
        //$input['email']=$request->email;
        $input['mobile']=$request->mobile;
        $input['is_active']=$request->is_active;
        $input['country']=$request->country;
        $input['state']=$request->state;
        $input['city']=$request->city;
        $input['pincode']=$request->pincode;
        $input['address']=$request->address;

        if($file=$request->file('photo_id')){
          $userimage = time().$file->getClientOriginalName();
          $location='public/userimages/';
          $file->move($location,$userimage);
          $photo = Photo::create(['file'=>$userimage]);
          $photo_id = $photo->id;
          //$user->profile_image = $photo_id;
          $input['profile_image']=$photo_id;
        }

        if(($request->role_id != '1') || ($request->role_id != '4')){
          if($file=$request->file('business_logo')){
            $userimage = time().$file->getClientOriginalName();
            $location='public/businessimages/';
            $file->move($location,$userimage);
            $photo = Photo::create(['file'=>$userimage]);
            $business_logo = $photo->id;
            //$user->business_logo = $business_logo;
            $input['business_logo']=$business_logo;
          }
          $input['business_name']=$request->business_name;
          //$input['business_email']=$request->business_email;
          $input['business_number']=$request->business_number;
          $input['business_desc']=$request->business_desc;
          $input['commission']=$request->commission;
        }
        $user->update($input);

        return redirect('users')->with('success','Information changed successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function ShowUserProfile(){
      $id=Auth::user()->id;
      $user = User::findOrFail($id);
      $country=Country::pluck('country_name','country_name')->all();
      $data['country']=$country;

      $data['user']=$user;
      $data['webpage']='Profile';
      $data['action']='Profile -> Edit Profile';
      $data['menu']='';

      return view('admin.user.showuserprofile')->with($data);
    }
    public function EditUserProfile(Request $request, $id){
      $this->validate($request, [
          'name' => 'required|max:191',
          'mobile' => 'required',
          'country' => 'required',
          'state' => 'required',
          'city' => 'required',
          'pincode' => 'required',
          'address' => 'required',
      ]);

      $user = User::findOrFail($id);
      $input = $request->all();
      if($file=$request->file('photo_id')){
        //if($user->photo!=""){
         // unlink(public_path()."/userimages/".$user->photo->file);
        //}
        $userimage = $id."_".time().$file->getClientOriginalName();
        $location='public/userimages/';
        $file->move($location,$userimage);
        $photo = Photo::create(['file'=>$userimage]);
        $photo_id = $photo->id;
        $input['photo_id'] = $photo_id;
      }
      $input['name']=$request->firstname . ' ' . $request->middlename . ' ' . $request->lastname;
      $user->update($input);
      return redirect('showuserprofile')->with('success','Information changed successfully');
    }
}
