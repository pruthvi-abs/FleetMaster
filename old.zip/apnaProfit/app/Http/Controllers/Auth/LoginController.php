<?php

namespace App\Http\Controllers\Auth;

use App\Providers\RouteServiceProvider;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use App\User;
use Auth;
use Illuminate\Http\Request;
use Hash;
use Mail;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Config;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    //protected $redirectTo = RouteServiceProvider::HOME;
    protected $redirectTo = '/dashboard';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    /*
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }
    */

    public function __construct()
    {
        //$this->middleware('guest')->except('logout');
        $this->middleware('guest', ['except' => ['logout', 'changePassword']]);
    }

    /* Admin Side */
    public function showLoginForm()
    {
        return view('auth.login');
    }

    public function changePassword(Request $request)
    {
        $customthemesetting = customthemesetting();
        //echo "Call...";die;
        if ($request->ajax()) {
            $currentPassword = $request->input('currentpassword');
            //return $currentPassword;die;
            $userid = Auth::user()->id;
            $check = User::select('password')
                ->where('id', $userid)
                ->first();
            if (Hash::check($currentPassword, $check['password'])) {
                $admin = User::find($userid);
                $admin->password = bcrypt($request->input('newpassword'));
                $admin->save();
                $message = 'Your Password has been updated.';
                $error = 1;
                $passwordmatch = '';

                /* Mail Start */
                $to_name = Auth::user()->name;
                $to_email = Auth::user()->email;
                $mail_data['name'] = Auth::user()->name;
                $mail_data['customthemesetting'] = $customthemesetting;
                Mail::send('admin.mail.changepassword', $mail_data, function ($message) use ($to_name, $to_email) {
                    $message->to($to_email, $to_name)->subject('Changed Password');
                });
                /* Mail End */
            } else {
                $message = 'Password update failed.';
                $error = 0;
                $passwordmatch = 'You have entered wrong current password.';
            }
            return response()->json(array('message' => $message, 'error' => $error, 'passwordmatch' => $passwordmatch), 200);
        }
    }

    public function redirectPath()
    {
        /*
        echo "---".Auth::user()->role_id;
        echo "---".Auth::user()->email;
        die;
        */
        if (Auth::check()) {
            // return Auth::user()->is_active;die;
            // print_r(Auth::user());
            // echo Auth::user()->is_active . '<br>';
            // echo Auth::user()->role_id . '<br>';
            // die;
            if (Auth::user()->is_active == 1) {
                if (Auth::user()->role_id == 1) {
                    Session::put('frontSession', Auth::user()->email);
                    return "/dashboard";
                } else if (Auth::user()->role_id == 2) {
                    Session::put('frontSession', Auth::user()->email);
                    return "/agencydashboard";
                } else if (Auth::user()->role_id == 3) {
                    Session::put('frontSession', Auth::user()->email);
                    return "/clientdashboard";
                } else {
                    Auth::logout();
                    Session::flash('notify', 'You have to no access of login page. Please contact to Administrator.');
                    //return redirect('/login');
                }
            } else {
                return redirect('/dashboard');
                // Auth::logout();
                // echo "call";die;
                // Session::flash('notify', 'You are diactive in the system. Please contact to Administrator.');
                //return redirect('/login');
            }
        } else {
            return redirect('/dashboard');
            // return redirect('/login');
        }
    }

    public function logout(Request $request)
    {
        Auth::logout();
        return redirect('/login');
    }
}
