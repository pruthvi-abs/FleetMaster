<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use OwenIt\Auditing\Contracts\Auditable;
use Illuminate\Database\Eloquent\SoftDeletes;

class Themesetting extends Model implements Auditable
{
    //
    use SoftDeletes;
    use \OwenIt\Auditing\Auditable;
    public $timestamps = true;
    protected $table = 'themesettings';
    protected $dates = ['deleted_at'];
    protected $fillable=['app_title','app_description','app_image','app_favicon','currency','front_email','front_mobile','smtp_website_name','smtp_server','smtp_port','smtp_email','smtp_email_pass','smtp_from_name','smtp_from_email','smtp_transport_exp','smtp_encryption'];
}
