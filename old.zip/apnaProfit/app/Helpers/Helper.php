<?php

use App\Themesetting;
use App\User;

function customthemesetting(){
  $systemconfig=Themesetting::select('app_title','app_description','app_image','app_favicon','currency','front_email','front_mobile','smtp_website_name','smtp_server','smtp_port','smtp_email','smtp_email_pass','smtp_from_name','smtp_from_email','smtp_transport_exp','smtp_encryption')->where('deleted_at',null)->where('id',1)->first();
  return $systemconfig;
}

function Username($user_id){
  $user=User::select('name')->where('deleted_at',null)->where('id',$user_id)->first();
  return $user->name;
}
