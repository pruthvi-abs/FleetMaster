-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 28, 2021 at 09:18 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `apnaprofit`
--

-- --------------------------------------------------------

--
-- Table structure for table `audits`
--

CREATE TABLE `audits` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `event` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `auditable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `auditable_id` bigint(20) UNSIGNED NOT NULL,
  `old_values` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_values` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(1023) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tags` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `audits`
--

INSERT INTO `audits` (`id`, `user_type`, `user_id`, `event`, `auditable_type`, `auditable_id`, `old_values`, `new_values`, `url`, `ip_address`, `user_agent`, `tags`, `created_at`, `updated_at`) VALUES
(18, 'App\\User', 1, 'created', 'App\\Role', 5, '[]', '{\"name\":\"Agency\",\"user_id\":\"1\",\"id\":5}', 'http://localhost/apnaProfit/roles', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0', NULL, '2021-06-22 06:28:00', '2021-06-22 06:28:00'),
(19, 'App\\User', 1, 'created', 'App\\Photo', 2, '[]', '{\"file\":\"1624368448favicon.png\",\"id\":2}', 'http://localhost/apnaProfit/users', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0', NULL, '2021-06-22 07:57:28', '2021-06-22 07:57:28'),
(20, 'App\\User', 1, 'created', 'App\\Photo', 3, '[]', '{\"file\":\"1624368572favicon.png\",\"id\":3}', 'http://localhost/apnaProfit/users', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0', NULL, '2021-06-22 07:59:32', '2021-06-22 07:59:32'),
(21, 'App\\User', 1, 'created', 'App\\Photo', 4, '[]', '{\"file\":\"1624368670favicon.png\",\"id\":4}', 'http://localhost/apnaProfit/users', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0', NULL, '2021-06-22 08:01:10', '2021-06-22 08:01:10'),
(22, 'App\\User', 1, 'created', 'App\\Photo', 5, '[]', '{\"file\":\"1624368722favicon.png\",\"id\":5}', 'http://localhost/apnaProfit/users', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0', NULL, '2021-06-22 08:02:02', '2021-06-22 08:02:02'),
(23, 'App\\User', 1, 'created', 'App\\User', 2, '[]', '{\"role_id\":\"2\",\"firstname\":\"Pruthvi\",\"middlename\":\"Deepakkumar\",\"lastname\":\"Dhamecha\",\"email\":\"pruthvi@gmail.com\",\"mobile\":\"1234567890\",\"profile_image\":5,\"is_active\":1,\"password\":\"$2y$10$AqHAnmUNwP8Z3JcagaK94eQk3Nfx1fLS05q2peY\\/UZEHnYsfsWMNe\",\"country\":\"INDIA\",\"state\":\"Gujarat\",\"city\":\"Vadodara\",\"pincode\":\"390011\",\"address\":\"Manjalpur\",\"business_name\":null,\"business_email\":null,\"business_number\":null,\"business_desc\":null,\"commission\":\"50\",\"id\":2}', 'http://localhost/apnaProfit/users', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0', NULL, '2021-06-22 08:02:02', '2021-06-22 08:02:02'),
(24, 'App\\User', 1, 'created', 'App\\Photo', 6, '[]', '{\"file\":\"1624368754favicon.png\",\"id\":6}', 'http://localhost/apnaProfit/users', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0', NULL, '2021-06-22 08:02:34', '2021-06-22 08:02:34'),
(25, 'App\\User', 1, 'created', 'App\\Photo', 7, '[]', '{\"file\":\"1624368779favicon.png\",\"id\":7}', 'http://localhost/apnaProfit/users', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0', NULL, '2021-06-22 08:02:59', '2021-06-22 08:02:59'),
(26, 'App\\User', 1, 'created', 'App\\User', 4, '[]', '{\"role_id\":\"2\",\"firstname\":\"Pruthvi\",\"middlename\":\"Deepakkumar\",\"lastname\":\"Dhamecha\",\"email\":\"pruthvi@gmail.com\",\"mobile\":\"1234567890\",\"profile_image\":7,\"is_active\":1,\"password\":\"$2y$10$BFh22aQ248RqnW2TU5W\\/w..wZN93CKcCsRU9qaJIlZKsPsQoKx10a\",\"country\":\"INDIA\",\"state\":\"Gujarat\",\"city\":\"Vadodara\",\"pincode\":\"390011\",\"address\":\"Manjalpur\",\"business_name\":null,\"business_email\":null,\"business_number\":null,\"business_desc\":null,\"commission\":\"50\",\"id\":4}', 'http://localhost/apnaProfit/users', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0', NULL, '2021-06-22 08:03:00', '2021-06-22 08:03:00');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` int(10) UNSIGNED NOT NULL,
  `country_code` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `country_code`, `country_name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'IN', 'INDIA', '2021-06-19 03:26:15', '2021-06-19 06:12:44', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_06_15_180530_create_roles_table', 1),
(5, '2021_06_15_180759_create_themesettings_table', 1),
(6, '2021_06_15_181518_create_photos_table', 1),
(7, '2021_06_19_051454_create_audits_table', 2),
(8, '2021_06_19_082303_create_countries_table', 2),
(9, '2021_06_21_170725_create_uniquenumbergenerates_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `photos`
--

CREATE TABLE `photos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `photos`
--

INSERT INTO `photos` (`id`, `file`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '1_1624102891thumb-1920-523395.jpg', '2021-06-19 06:11:31', '2021-06-19 06:11:31', NULL),
(2, '1624368448favicon.png', '2021-06-22 07:57:28', '2021-06-22 07:57:28', NULL),
(3, '1624368572favicon.png', '2021-06-22 07:59:32', '2021-06-22 07:59:32', NULL),
(4, '1624368670favicon.png', '2021-06-22 08:01:10', '2021-06-22 08:01:10', NULL),
(5, '1624368722favicon.png', '2021-06-22 08:02:02', '2021-06-22 08:02:02', NULL),
(6, '1624368754favicon.png', '2021-06-22 08:02:34', '2021-06-22 08:02:34', NULL),
(7, '1624368779favicon.png', '2021-06-22 08:02:59', '2021-06-22 08:02:59', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `created_at`, `updated_at`, `user_id`, `deleted_at`) VALUES
(1, 'Admin', '2021-06-18 12:35:29', '2021-06-19 01:44:22', 1, NULL),
(2, 'Client', '2021-06-19 01:45:41', '2021-06-19 01:45:41', 1, NULL),
(3, 'Agency', '2021-06-19 01:45:57', '2021-06-19 01:45:57', 1, NULL),
(4, 'Customer', '2021-06-19 01:46:27', '2021-06-19 06:18:48', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `themesettings`
--

CREATE TABLE `themesettings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `app_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `app_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `app_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `app_favicon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `front_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `front_mobile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_website_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_server` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_port` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_email_pass` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_from_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_from_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_transport_exp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_encryption` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `themesettings`
--

INSERT INTO `themesettings` (`id`, `app_title`, `app_description`, `app_image`, `app_favicon`, `currency`, `front_email`, `front_mobile`, `smtp_website_name`, `smtp_server`, `smtp_port`, `smtp_email`, `smtp_email_pass`, `smtp_from_name`, `smtp_from_email`, `smtp_transport_exp`, `smtp_encryption`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Apna Profit', 'Vadodara, India', '1624101460logo.png', '1624101292favicon.png', '₹', 'noreply@neoinventions.com', '1234567890', 'http://absolutewebdevelopment.in/apnaProfit/', 'mail.neoinventions.com', '465', 'noreply@neoinventions.com', 'noreply@123', 'Apna Profit', 'noreply@neoinventions.com', 'sendmail', 'ssl', NULL, '2021-06-19 05:47:40', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `uniquenumbergenerates`
--

CREATE TABLE `uniquenumbergenerates` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uniquenumber` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `profile_image` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` int(10) UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `middlename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` int(11) DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pincode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_logo` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_desc` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `commission` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `profile_image`, `role_id`, `name`, `firstname`, `middlename`, `lastname`, `email`, `email_verified_at`, `password`, `is_active`, `address`, `city`, `state`, `country`, `pincode`, `mobile`, `business_logo`, `business_name`, `business_email`, `business_number`, `business_desc`, `commission`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '', 1, 'Pruthvi Dipakkumar Dhamecha', 'Pruthvi', 'Dipakkumar', 'Dhamecha', 'absdevlop@gmail.com', NULL, '$2y$10$K6V5gOfFECg8GRAiRqmPteagzWx0PV...2ka0snFcAN2RXjagN196', 1, 'Manjalpur', 'Vadodara', 'Gujarat', 'INDIA', '390011', '1234567890', '', 'ABS', 'pruthvi.abs@gmail.com', '1234567890', 'Absolute Web', '50', 'CiopQh4q7asaFpYaoiTufdXbpllTim8eirG469OJj26tPZ3iQlZG4VPUC8Gs', '2021-06-18 06:19:32', '2021-06-19 06:11:23', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audits`
--
ALTER TABLE `audits`
  ADD PRIMARY KEY (`id`),
  ADD KEY `audits_auditable_type_auditable_id_index` (`auditable_type`,`auditable_id`),
  ADD KEY `audits_user_id_user_type_index` (`user_id`,`user_type`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `photos`
--
ALTER TABLE `photos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `themesettings`
--
ALTER TABLE `themesettings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uniquenumbergenerates`
--
ALTER TABLE `uniquenumbergenerates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audits`
--
ALTER TABLE `audits`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `photos`
--
ALTER TABLE `photos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `themesettings`
--
ALTER TABLE `themesettings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `uniquenumbergenerates`
--
ALTER TABLE `uniquenumbergenerates`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
